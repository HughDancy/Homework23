import Foundation
import CommonCrypto
import CryptoKit

func makeUrlSessionWithTimeout(_ timeout: TimeInterval) -> URLSession {
    let configuration = URLSessionConfiguration.default
    configuration.allowsCellularAccess = true
    configuration.waitsForConnectivity = true
    configuration.timeoutIntervalForRequest = timeout
    configuration.httpMaximumConnectionsPerHost = 100
    configuration.urlCache = URLCache()
    
    return URLSession(configuration: configuration)
}

let zeldaUrl = "https://botw-compendium.herokuapp.com/api/v2."
let urlSession = makeUrlSessionWithTimeout(20)

func getData(urlRequest: String) {
    let urlRequest = URL(string: urlRequest)
    guard let url = urlRequest else { return }
    urlSession.dataTask(with: url) { data, response, error in
        if error != nil {
            
        } else  if let response = response as? HTTPURLResponse, response.statusCode == 200 {
            print(response.statusCode)
            guard let data = data else { return }
            let dataAsString = String(data: data, encoding: .utf8)
            print(dataAsString as Any)
        } else  if let response = response as? HTTPURLResponse, response.statusCode != 200 {
            print("Erorr \(response.statusCode)")
        }
    }.resume()
}

getData(urlRequest: zeldaUrl)

// ЗАДАНИЕ СО ЗВЕЗДОЧКОЙ

func MD5(string: String) -> Data {
    let length = Int(CC_MD5_DIGEST_LENGTH)
    let messageData = string.data(using:.utf8)!
    var digestData = Data(count: length)
    
    _ = digestData.withUnsafeMutableBytes { digestBytes -> UInt8 in
        messageData.withUnsafeBytes { messageBytes -> UInt8 in
            if let messageBytesBaseAddress = messageBytes.baseAddress, let digestBytesBlindMemory = digestBytes.bindMemory(to: UInt8.self).baseAddress {
                let messageLength = CC_LONG(messageData.count)
                CC_MD5(messageBytesBaseAddress, messageLength, digestBytesBlindMemory)
            }
            return 0
        }
    }
    return digestData
}

let marvelBaseUrl = "https://gateway.marvel.com:443/v1/public/characters/10176032"
let publicKey = "668bb98feb92f9e01274eab33bf2d272"
let privateKty = "1046324be64ba0efff8dad4306c13e282e826d59"
let ts = "1"

func marvelData(ts: String, publicKey: String, privateKey: String) {
    let baseUrl = "https://gateway.marvel.com:443/v1/public/characters/1017603"
    let hash = MD5(string: ts + privateKey + publicKey)
    let md5Hash = hash.map {  String(format: "%02hhx", $0) }.joined()
    getData(urlRequest: "\(baseUrl)?ts=\(ts)&apikey=\(publicKey)&hash=\(md5Hash)")
}

marvelData(ts: ts, publicKey: publicKey, privateKey: privateKty)


